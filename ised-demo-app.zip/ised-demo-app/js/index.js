import { strings, setLanguage } from './strings.js'
import { initActivity } from './activities/initActivity.js';
import * as utils from './utils.js';

function getAndSetLanguage() {
    var urlParams = new URLSearchParams(window.location.search);

    if (urlParams.has('lang')) {
        setLanguage(urlParams.get('lang'));
    } else {
        setLanguage('en');
    }
}

function setHeader() {
    document.title = strings.documentTitle;
    $('#goButton').text(strings.goButtonText);
    $('#restartButton').text(strings.restartButtonText);
}

function setBoxTitles() {
    $('#holderBoxTitle').text(strings.holderBoxTitle);
    $('#issuerBoxTitle').text(strings.issuerBoxTitle);
    $('#verifierBoxTitle').text(strings.verifierBoxTitle);

    $('#issuerLog h5').text(strings.issuerLogBoxTitle);
    $('#holderLog h5').text(strings.holderLogBoxTitle);
    $('#verifierLog h5').text(strings.verifierLogBoxTitle);
}

function setActivitiesMenuItemsStrings() {
    $('<option value="makeAChoice" selected>' + strings.activities.dropdownTitle + '</option>').appendTo('#demoSelection');
    $('<option value="completeDriverTest">' + strings.activities.completeDriverTest + '</option>').appendTo('#demoSelection');
    $('<option value="getDriverLicense">' + strings.activities.getDriverLicense + '</option>').appendTo('#demoSelection');
    $('<option value="buyACar">' + strings.activities.buyACar + '</option>').appendTo('#demoSelection');
    $('<option value="obtainCarRegistration">' + strings.activities.obtainCarRegistration + '</option>').appendTo('#demoSelection');
    $('<option value="getInsurance">' + strings.activities.getInsurance + '</option>').appendTo('#demoSelection');
    $('<option value="relocate">' + strings.activities.relocate + '</option>').appendTo('#demoSelection');

    $('#completeDriverTest').text(strings.activities.completeDriverTest)
    $('#getDriverLicense').text(strings.activities.getDriverLicense)
    $('#buyACar').text(strings.activities.buyACar)
    $('#obtainCarRegistration').text(strings.activities.obtainCarRegistration)
    $('#getInsurance').text(strings.activities.getInsurance)
    $('#relocate').text(strings.activities.relocate)
}

function setThankYouModelStrings() {
    $('#successMessageModal .modal-title').text(strings.thankYouModal.titleText);
    $('#successMessageModal .modal-body').text(strings.thankYouModal.bodyText);
    $('#successMessageModal .modal-footer button').text(strings.thankYouModal.closeButtonText);
}

function setRegistry() {
    $('#resilientInfraText').text(strings.resilientRegistryInfraText);
    $('#issuingDocumentToRegistry').text(strings.issuingDocumentToRegistry);
    $('#verifyingDocumentFromRegistry').text(strings.verifyingDocumentAgainstRegistry);
}

function prepareSummaryModal(selected) {
    $('#demoSummaryLabel').text(strings.activities[selected]);
    $('#demoSummary').html(strings.activityIntros[selected]);
    $('#demoSummaryIdLingo').html(strings.activityIntros[`${selected}IdLingo`]);
    $('#startDemoBtn').text(strings.summaryModalButtonText);
}

function prepareScenarioSidePanel(selected) {
    $('#scenarioTitle strong').text(strings.activities[selected]);
    $('#scenarioSummary').html(strings.activityIntros[selected]);
    $('#scenarioIdLingo').html(strings.activityIntros[`${selected}IdLingo`]);
    $('#scenarioPanelButton').text(strings.scenario);
}

function positionDragAndDropHints() {
    $('#veriferDragAndDropHint').position({ of: $('#verifiedDocument'), my: 'top', at: 'bottom right' });
    $('#veriferDragAndDropHint').animate({ top: '+=100px', left: '+=30px' });

    $('#issuerDragAndDropHint').position({ of: $('#issuedDocuments'), my: 'top', at: 'bottom left' });
    $('#issuerDragAndDropHint').animate({ top: '+=100px', left: '-=120px' });
}

$(document).ready(function () {
    window.scrollTo(0, 0);
    getAndSetLanguage(); // <----- IMPORTANT, must be called first
    setHeader();
    setActivitiesMenuItemsStrings();
    setBoxTitles();
    setThankYouModelStrings();

    setRegistry();
    positionDragAndDropHints();

    $('#demoSelection').change(function () {
        var selected = this.value;

        prepareSummaryModal(selected);
        prepareScenarioSidePanel(selected);
        initActivity(selected);
    });

});
