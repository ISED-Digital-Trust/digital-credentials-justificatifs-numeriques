import { strings } from './strings.js';

function setDocumentsInHand(documents) {
    $('#heldDocuments').empty();
    $('#issuerBox').empty();

    documents.forEach(function (document) {
        appendDocumentsInHand(document);
    });
}

function getDocumentImgElement(document) {
    return $(`<img 
        src="${document.imageUrl}" 
        data-bs-toggle="tooltip" 
        data-bs-placement="top" 
        data-bs-animation="true"
        data-bs-title="${document.text}"
        class="mx-1"
        width="50">`).attr('id', document.id).tooltip({ trigger: 'hover' });
}

function appendDocumentsInHand(document) {
    getDocumentImgElement(document).appendTo('#heldDocuments');
}

function addDocInHandsFromIssuerBoxDropZone(document) {
    getDocumentImgElement(document).appendTo('#issuedDocuments');
}

function setSteps(steps, sidebarDescription) {
    $("#stepsContainer").empty();
    let stepCounter = 1;

    var firstStepId = null;

    steps.forEach(function (element) {
        var contDivId = `${element.id}_container`;
        var contDiv = `<div id="${contDivId}" class="col-2"></div>`;
        $(contDiv).appendTo('#stepsContainer');

        var stepId = `${element.id}_step`
        var isOn = 'off';
        if (stepCounter == 1) {
            isOn = 'on';
            firstStepId = stepId;
        }
        var stepDiv = $(`<div id="${stepId}" class="step ${isOn} mx-auto float-start">${stepCounter}</div><p class="step-text">${element.text}</p>`);
        $(stepDiv).appendTo(`#${contDivId}`);
        stepCounter++;
    });

    $('#sidePanelStepNumber').show();

    setStepOn(firstStepId, '1', sidebarDescription);
}

function setVerifierBox(id) {
    $('<div class="verifier-box-item"></div>').attr('id', id).appendTo('#motorVehicleOfficeDropZone');
}

function setIssuerBox(issuerBoxItems) {
    issuerBoxItems.forEach(function (element) {
        $(`<img src="${element.imageUrl}" 
            data-bs-toggle="tooltip" 
            data-bs-placement="top" 
            data-bs-animation="true"
            data-bs-title="${element.text}"/>`).attr('id', element.id).appendTo('#issuerDropZone');

        $(`#${element.id}`).tooltip({ trigger: 'hover' });
    });
}

function enableDragAndDrop(dragAndDropOptions) {
    var helper = undefined;

    if (!dragAndDropOptions.isIssuer) {
        $(dragAndDropOptions.draggableId).appendTo('#verifiedDocument');
        helper = 'clone'
        $('#veriferDragAndDropHint').removeClass('invisible');
        setVerifierBox(dragAndDropOptions.droppableId.substring(1));
    } else {
        $('<div class="verifier-box-item"></div>').attr('id', dragAndDropOptions.droppableId.substring(1)).appendTo('#issuedDocuments');
        $('#issuerDragAndDropHint').removeClass('invisible');
    }

    $(dragAndDropOptions.draggableId).draggable({
        helper: helper,
        cursor: 'move',
        revert: true
    });

    $(dragAndDropOptions.droppableId).droppable({
        accept: dragAndDropOptions.draggableId,
        hoverClass: dragAndDropOptions.hoverClass,
        drop: function (event, ui) {
            if (!dragAndDropOptions.isIssuer) {
                $(dragAndDropOptions.draggableId).clone().appendTo(this);
                $(dragAndDropOptions.draggableId).appendTo('#heldDocuments');
            }

            dragAndDropOptions.dropHandler(event, ui);
        }
    });
}

function disableDragAndDrop(disableOptions) {
    $(disableOptions.draggableId).draggable('disable');
    $(disableOptions.droppableId).droppable('disable');
    if (disableOptions.isIssuer) {
        $(disableOptions.draggableId).position({ of: $(disableOptions.droppableId), my: 'center', at: 'center' });
        $('#issuerDragAndDropHint').addClass('invisible');
        $(disableOptions.droppableId).remove();
    }
    $(disableOptions.draggableId).draggable('option', 'revert', false);
}

function logMessage(logId, message) {
    $(logId + ' .empty-log').remove();
    $('.log-entry').removeClass('latest');
    var logEntryReceiver = `${logId} .list-group`;

    $('<li class="list-group-item log-entry latest">' + message + '</li>').appendTo(logEntryReceiver);
}

function logMessage2(logId, message, nbEmptyLogs) {
    if (nbEmptyLogs > 0) {
        for (var i = 0; i < nbEmptyLogs; i++) {
            logMessage(logId, '');
        }
    }

    logMessage(logId, message);
}

function showThankYouMessage(isRemote) {
    var personImageSrc = 'img/ico_user-happy.png';
    if (isRemote) {
        personImageSrc = 'img/ico_user-laptop-happy.png'
    }
    setPersonImage('#personImageContainer', personImageSrc, 'left', 'center');
    $('#successMessageModal').modal('show');
    removeTooltips();
    dimIssuerBoxLogo();
    dimVerifierBoxLogo();
    $('#sidePanelStepNumber').hide().empty();
    $('#sidePanelStepNumberText').empty();
}

function removeTooltips() {
    $('.tooltip-arrow, .tooltip-inner').remove(); // A bug with Bootstrap tooltips with drag and drop.
    $('[data-bs-toggle="tooltip"]').tooltip({ trigger: 'hover' });
}

function positionPersonImage() {
    $('#personImage').attr('src', 'img/ico_user-54.png');
    $('#personImage').css({
        top: '',
        left: ''
    });
}

var animateStepInterval = null;

function setStepOn(stepSelector, stepNumber, stepDescription) {
    $(stepSelector).removeClass('off');
    $(stepSelector).addClass('on');

    $('#sidePanelStepNumber').text(stepNumber);
    $('#sidePanelStepNumberText').text(stepDescription);
}

function setStepOff(stepSelector) {
    $(stepSelector).removeClass('on');
    $(stepSelector).addClass('off');
}

function resetLogs() {
    $('.logs ul').empty();

    $(`<li class="list-group-item log-entry empty-log">${strings.noLogEntryText}</li>`).appendTo('#issuerLog ul');
    $(`<li class="list-group-item log-entry empty-log">${strings.noLogEntryText}</li>`).appendTo('#holderLog ul');
    $(`<li class="list-group-item log-entry empty-log">${strings.noLogEntryText}</li>`).appendTo('#verifierLog ul');
}

function displayRegistryArrows(left, right) {
    // var leftArrow = $('.registry-left-arrow');
    var rightArrow = $('.registry-right-arrow');

    // if (left) {
    //     leftArrow.removeClass('invisible');
    // } else {
    //     leftArrow.addClass('invisible');
    // }

    if (right) {
        rightArrow.removeClass('invisible');
    } else {
        rightArrow.addClass('invisible');
    }
}

function initVerifierBox(imgUrl, tooltipText) {
    $('#motorVehicleOfficeTop').empty();

    $(`<img id="verifierLogo" src="${imgUrl}" class="verifier-logo"
        data-bs-toggle="tooltip" 
        data-bs-placement="top" 
        data-bs-animation="true"
        data-bs-title="${tooltipText}">`).tooltip({ trigger: 'hover' }).appendTo('#motorVehicleOfficeTop');

    $('#motorVehicleOfficeTop').removeClass('invisible');
    $('#motorVehicleOfficeDropZone').empty();
}

function initIssuerBox(imgUrl, tooltipText) {
    $('#issuerBoxHeaderTop').empty();

    $(`<img id="issuerLogo" src="${imgUrl}" class="verifier-logo"
        data-bs-toggle="tooltip" 
        data-bs-placement="top" 
        data-bs-animation="true"
        data-bs-title="${tooltipText}">`).tooltip({ trigger: 'hover' }).appendTo('#issuerBoxHeaderTop');

    $('#issuerBoxHeaderTop').removeClass('invisible');
    $('#issuerDropZone').empty();
}

function setPersonImage(selector, imgUrl, oldPosition, newPosition) {
    var imgSelector = `${selector} img`;
    $(imgSelector).animate({ opacity: '0' });
    setTimeout(function () {
        $(imgSelector).removeClass(`align-self-${oldPosition}`);
        $(imgSelector).addClass(`align-self-${newPosition}`);
        $(imgSelector).attr('src', imgUrl);
        $(imgSelector).animate({ opacity: '1' });
    }, 500);
}

function setPersonBeginImage(isRemote) {
    if (isRemote) {
        setPersonImage('#personImageContainer', 'img/ico_user-laptop.png', '', 'center');
    } else {
        setPersonImage('#personImageContainer', 'img/ico_user-40.png', '', 'center');
    }

}

function undimVerifierBoxLogo() {
    $('#verifierLogo').animate({ opacity: '1' });
}

function dimVerifierBoxLogo() {
    $('#verifierLogo').animate({ opacity: '0.3' });
}

function undimIssuerBoxLogo() {
    $('#issuerLogo').animate({ opacity: '1' });
}

function dimIssuerBoxLogo() {
    $('#issuerLogo').animate({ opacity: '0.3' });
}

function clearMyTimeouts(timeouts) {
    console.log(`clearing ${timeouts.length} timeouts`);
    timeouts.forEach(function (timeout) {
        clearTimeout(timeout);
    });
}

function enableStartDemoClick(clickAction, bubbleText, hideBubbleAfterClicking) {
    const selector = '#personImage, #clickMeText';

    $('#clickMeTextH1').text(bubbleText);
    $('.emphasis').show('slow');
    $(selector).off('click');
    $(selector).on('click', function () {
        if (hideBubbleAfterClicking) {
            $(selector).off('click');
            $('.emphasis').hide('slow');
        }

        clickAction();
    });
}

function showRegistryInteraction(showIssuer, followUpAction) {
    displayRegistryArrows(showIssuer, !showIssuer);
    setTimeout(function () {
        displayRegistryArrows(false, false);
        followUpAction();
    }, 3000);
}

export {
    setDocumentsInHand,
    setSteps,
    enableDragAndDrop,
    disableDragAndDrop,
    setVerifierBox,
    setIssuerBox,
    logMessage,
    showThankYouMessage,
    positionPersonImage,
    setStepOn,
    setStepOff,
    resetLogs,
    displayRegistryArrows,
    initVerifierBox,
    setPersonImage,
    dimVerifierBoxLogo,
    initIssuerBox,
    undimIssuerBoxLogo,
    undimVerifierBoxLogo,
    dimIssuerBoxLogo,
    clearMyTimeouts,
    logMessage2,
    setPersonBeginImage,
    removeTooltips,
    enableStartDemoClick,
    appendDocumentsInHand,
    showRegistryInteraction,
    addDocInHandsFromIssuerBoxDropZone,
    getDocumentImgElement
};
