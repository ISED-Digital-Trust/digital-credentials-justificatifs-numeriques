import { strings } from '../strings.js';
import * as utils from '../utils.js';

function init() {
    utils.displayRegistryArrows(false, false);
    fillInitalSteps();
    fillDocsInHand();
    $('#motorVehicleOfficeDropZone').css('width', '325px');
    prepareFirstStep();
}

function fillInitalSteps() {

    utils.setSteps([
        {
            id: 'stepBox1',
            text: strings.steps.stepVisitDigitalGovServiceDesk
        },
        {
            id: 'stepBox2',
            text: strings.steps.stepRequestNewDriverLicense
        },
        {
            id: 'stepBox3',
            text: strings.steps.stepPresentProofOfResidency
        },
        {
            id: 'stepBox4',
            text: strings.steps.stepShowDriversLicense
        },
        {
            id: 'stepBox5',
            text: strings.steps.stepShowCarRegistration
        }
    ], strings.steps.descriptions.relocate.stepVisitDigitalGovServiceDesk);
}

function fillDocsInHand() {
    utils.setDocumentsInHand([
        {
            id: 'docInHandApartmentLease',
            text: strings.documentsInHand.apartmentLease,
            imageUrl: 'img/ico_appart-lease.png'
        },
        {
            id: 'docInHandDriversLicense',
            text: strings.documentsInHand.driversLicenseProv1,
            imageUrl: 'img/ico_drivers-license-prov1.png'
        },
        {
            id: 'docInHandCarRegistration',
            text: strings.documentsInHand.carRegistrationProv1,
            imageUrl: 'img/ico_car-registration-prov1.png'
        },
        {
            id: 'docInCarInsurance',
            text: strings.documentsInHand.carInsurance,
            imageUrl: 'img/ico_proof-insurance.png'
        },
        {
            id: 'docInHandHealthCard',
            text: strings.documentsInHand.healthCardProv1,
            imageUrl: 'img/ico_health-card-prov1.png'
        },
        {
            id: 'docInHandCarProofOfOwnership',
            text: strings.documentsInHand.carProofOfOwnership,
            imageUrl: 'img/ico_proof-ownership.png'
        }
    ]);
}

function handlePersonVisitingDigitalGovernment() {
    utils.setStepOff('#stepBox1_step');
    utils.setStepOn('#stepBox2_step', '2', strings.steps.descriptions.relocate.stepRequestNewDriverLicense);

    utils.enableStartDemoClick(function () {
        utils.setStepOff('#stepBox2_step');
        utils.setStepOn('#stepBox3_step', '3', strings.steps.descriptions.relocate.stepPresentProofOfResidency);

        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 1);

        $('#testResults').animate({ opacity: '1' });

        prepareThirdStep();
    }, strings.clickMeButtonTextPerformStep, true);
}

function prepareFirstStep() {
    utils.setPersonBeginImage(true);
    utils.dimIssuerBoxLogo();
    utils.enableStartDemoClick(function () {
        utils.setPersonImage('#personImageContainer', 'img/ico_user-laptop-talk-right.png', 'center', 'end');
        $('#personImage').off('click');
        handlePersonVisitingDigitalGovernment();
    }, strings.clickMeButtonTextVisit, false);
}

function setStepBoxes(startNumber, steps, currentStepDescription) {
    var currentNumber = startNumber;

    $('#stepBox1_container p').remove();
    $('#stepBox1_step').text(`${currentNumber}`);
    $(`<p class="step-text">${steps[0]}</p>`).appendTo('#stepBox1_container');

    currentNumber++;

    $('#stepBox2_container p').remove();
    $('#stepBox2_step').text(`${currentNumber}`);
    $(`<p class="step-text">${steps[1]}</p>`).appendTo('#stepBox2_container');

    currentNumber++;

    $('#stepBox3_container p').remove();
    $('#stepBox3_step').text(`${currentNumber}`);
    $(`<p class="step-text">${steps[2]}</p>`).appendTo('#stepBox3_container');
    $('#sidePanelStepNumber').text(`${currentNumber}`);
    $('#sidePanelStepNumberText').text(currentStepDescription);

    currentNumber++;

    $('#stepBox4_container p').remove();
    $('#stepBox4_step').text(`${currentNumber}`);
    $(`<p class="step-text">${steps[3]}</p>`).appendTo('#stepBox4_container');

    currentNumber++;

    $('#stepBox5_container p').remove();
    $('#stepBox5_step').text(`${currentNumber}`);
    $(`<p class="step-text">${steps[4]}</p>`).appendTo('#stepBox5_container');
}

function handlePersonShowingProofOfResidency() {
    $('#veriferDragAndDropHint').addClass('invisible');

    $('#proofOfResidenceVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandApartmentLeaseVerifierBox',
        text: strings.documentsInHand.apartmentLease,
        imageUrl: 'img/ico_appart-lease.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.logMessage('#holderLog', strings.logs.consentToShareId);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandApartmentLease',
            droppableId: '#proofOfResidenceVerifierBox',
            isIssuer: false
        });
        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 2);

        setStepBoxes(2, [
            strings.steps.stepRequestNewDriverLicense,
            strings.steps.stepPresentProofOfResidency,
            strings.steps.stepShowDriversLicense,
            strings.steps.stepShowCarRegistration,
            strings.steps.stepShowCarInsurance
        ], strings.steps.descriptions.relocate.stepShowDriversLicense);

        $('#driversLicenseVerifierBox').animate({ opacity: '1' });

        utils.enableDragAndDrop({
            draggableId: '#docInHandDriversLicense',
            droppableId: '#driversLicenseVerifierBox',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: handlePersonShowingDriversLicense,
            isIssuer: false
        });
    });
}

function handlePersonShowingDriversLicense() {
    $('#veriferDragAndDropHint').addClass('invisible');

    $('#driversLicenseVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandDriversLicenseVerifierBox',
        text: strings.documentsInHand.driversLicenseProv1,
        imageUrl: 'img/ico_drivers-license-prov1.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.logMessage('#holderLog', strings.logs.consentToShareId);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandDriversLicense',
            droppableId: '#driversLicenseVerifierBox',
            isIssuer: false
        });

        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 2);

        setStepBoxes(3, [
            strings.steps.stepPresentProofOfResidency,
            strings.steps.stepShowDriversLicense,
            strings.steps.stepShowCarRegistration,
            strings.steps.stepShowCarInsurance,
            strings.steps.stepReceiveNewDriversLicense
        ], strings.steps.descriptions.relocate.stepShowCarRegistration);

        prepareFifthStep();
    });
}

function handlePersonShowingCarRegistraion() {
    $('#veriferDragAndDropHint').addClass('invisible');

    $('#carRegistrationVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandCarRegistrationVerifierBox',
        text: strings.documentsInHand.carRegistrationProv1,
        imageUrl: 'img/ico_car-registration-prov1.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.logMessage('#holderLog', strings.logs.consentToShareId);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandCarRegistration',
            droppableId: '#carRegistrationVerifierBox',
            isIssuer: false
        });
        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 2);

        setStepBoxes(4, [
            strings.steps.stepShowDriversLicense,
            strings.steps.stepShowCarRegistration,
            strings.steps.stepShowCarInsurance,
            strings.steps.stepReceiveNewDriversLicense,
            strings.steps.stepReceiveNewCarRegistration
        ], strings.steps.descriptions.relocate.stepShowCarInsurance);

        prepareSixthStep();
    });
}

function handlePersonShowingCarInsurance() {
    $('#veriferDragAndDropHint').addClass('invisible');

    $('#carInsuranceVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInCarInsuranceVerifierBox',
        text: strings.documentsInHand.carInsurance,
        imageUrl: 'img/ico_proof-insurance.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.logMessage('#holderLog', strings.logs.consentToShareId);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInCarInsurance',
            droppableId: '#carInsuranceVerifierBox',
            isIssuer: false
        });
        setStepBoxes(5, [
            strings.steps.stepShowCarRegistration,
            strings.steps.stepShowCarInsurance,
            strings.steps.stepReceiveNewDriversLicense,
            strings.steps.stepReceiveNewCarRegistration,
            strings.steps.stepGiveConsentToNotifyInsuranceCompany
        ], strings.steps.descriptions.relocate.stepReceiveNewDriversLicense);

        prepareSeventhStep();
    });
}

function handlePersonReceivingNewDriverLicense() {
    utils.removeTooltips();
    utils.disableDragAndDrop({
        draggableId: '#docInHandDriverLicenseProv2',
        droppableId: '#driversLicenseDroppable',
        isIssuer: true
    });

    $('#docInHandDriverLicenseProv2').remove();
    $('#driversLicenseDroppable').remove();

    utils.logMessage2('#holderLog', strings.logs.storeDriversLicense, 2);

    utils.addDocInHandsFromIssuerBoxDropZone({
        id: 'docInHandsDriversLicenseProv2',
        text: strings.documentsInHand.driversLicenseProv2,
        imageUrl: 'img/ico_drivers-license-prov2.png'
    });

    utils.showRegistryInteraction(true, function () {
        setStepBoxes(6, [
            strings.steps.stepShowCarInsurance,
            strings.steps.stepReceiveNewDriversLicense,
            strings.steps.stepReceiveNewCarRegistration,
            strings.steps.stepGiveConsentToNotifyInsuranceCompany,
            strings.steps.stepShowHealthCard
        ], strings.steps.descriptions.relocate.stepReceiveNewCarRegistration);

        prepareEigthStep();
    });
}

function handlePersonReceivingNewCarRegistration() {
    utils.removeTooltips();
    utils.disableDragAndDrop({
        draggableId: '#docInHandCarRegistrationProv2',
        droppableId: '#carRegistrationDroppable',
        isIssuer: true
    });

    utils.logMessage2('#holderLog', strings.logs.storeCarRegistration, 1);

    $('#docInHandCarRegistrationProv2').remove();
    $('#carRegistrationDroppable').remove();

    utils.addDocInHandsFromIssuerBoxDropZone({
        id: 'docInHandsCarRegistrationProv2',
        text: strings.documentsInHand.carRegistrationProv2,
        imageUrl: 'img/ico_car-registration-prov2.png'
    });

    utils.showRegistryInteraction(true, function () {
        setStepBoxes(7, [
            strings.steps.stepReceiveNewDriversLicense,
            strings.steps.stepReceiveNewCarRegistration,
            strings.steps.stepGiveConsentToNotifyInsuranceCompany,
            strings.steps.stepShowHealthCard,
            strings.steps.stepReceiveNewHealthCard
        ], strings.steps.descriptions.relocate.stepGiveConsentToNotifyInsuranceCompany);

        utils.logMessage2('#verifierLog', strings.logs.requestDigitalId, 4);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 1)

        prepareNinthStep();
    });
}

function handlePersonShowingHealthCard() {
    $('#veriferDragAndDropHint').addClass('invisible');

    $('#healthCardVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandHealthCardVerifierBox',
        text: strings.documentsInHand.healthCardProv1,
        imageUrl: 'img/ico_health-card-prov1.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.logMessage2('#holderLog', strings.logs.consentToShareId, 0);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandHealthCard',
            droppableId: '#healthCardVerifierBox',
            isIssuer: false
        });
        utils.setStepOff('#stepBox4_step');
        utils.setStepOn('#stepBox5_step', '11', strings.steps.descriptions.relocate.stepReceiveNewHealthCard);

        setTimeout(function () {
            prepareLastStep();
        }, 1000);
    });
}

function prepareThirdStep() {
    $('#proofOfResidenceVerifierBox').animate({ opacity: '1' });
    utils.enableDragAndDrop({
        draggableId: '#docInHandApartmentLease',
        droppableId: '#proofOfResidenceVerifierBox',
        containment: '#bodyContent',
        hoverClass: 'droppable-hover',
        dropHandler: handlePersonShowingProofOfResidency,
        isIssuer: false
    });
}

function prepareFifthStep() {
    $('#carRegistrationVerifierBox').animate({ opacity: '1' });
    utils.enableDragAndDrop({
        draggableId: '#docInHandCarRegistration',
        droppableId: '#carRegistrationVerifierBox',
        containment: '#bodyContent',
        hoverClass: 'droppable-hover',
        dropHandler: handlePersonShowingCarRegistraion,
        isIssuer: false
    });
}

function prepareSixthStep() {
    $('#carInsuranceVerifierBox').animate({ opacity: '1' });
    utils.enableDragAndDrop({
        draggableId: '#docInCarInsurance',
        droppableId: '#carInsuranceVerifierBox',
        containment: '#bodyContent',
        hoverClass: 'droppable-hover',
        dropHandler: handlePersonShowingCarInsurance,
        isIssuer: false
    });
}

function prepareSeventhStep() {
    setTimeout(function () {
        utils.logMessage2('#issuerLog', strings.logs.issueDriversLicense, 16);

        utils.setPersonImage('#personImageContainer', 'img/ico_user-laptop-talk-left.png', 'end', 'start');
        utils.setIssuerBox([{
            id: 'docInHandDriverLicenseProv2',
            text: strings.documentsInHand.driversLicenseProv2,
            imageUrl: 'img/ico_drivers-license-prov2.png'
        }]);

        $('#driversLicenseDroppable').animate({ opacity: '1' });

        utils.enableDragAndDrop({
            draggableId: '#docInHandDriverLicenseProv2',
            droppableId: '#driversLicenseDroppable',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: handlePersonReceivingNewDriverLicense,
            isIssuer: true
        });
    }, 1000);
}

function prepareEigthStep() {
    setTimeout(function () {
        utils.setPersonImage('#personImageContainer', 'img/ico_user-laptop-talk-left.png', 'end', 'start');
        utils.setIssuerBox([{
            id: 'docInHandCarRegistrationProv2',
            text: strings.documentsInHand.carRegistrationProv2,
            imageUrl: 'img/ico_car-registration-prov2.png'
        }]);

        utils.logMessage2('#issuerLog', strings.logs.issueCarRegistration, 1);

        utils.enableDragAndDrop({
            draggableId: '#docInHandCarRegistrationProv2',
            droppableId: '#carRegistrationDroppable',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: handlePersonReceivingNewCarRegistration,
            isIssuer: true
        });

    }, 1000);
}

function prepareNinthStep() {

    utils.enableStartDemoClick(function () {
        utils.setStepOff('#stepBox3_step');
        utils.setStepOn('#stepBox4_step', '10', strings.steps.descriptions.relocate.stepShowHealthCard);

        utils.setPersonImage('#personImageContainer', 'img/ico_user-laptop-talk-right.png', 'start', 'end');

        utils.enableDragAndDrop({
            draggableId: '#docInHandHealthCard',
            droppableId: '#healthCardVerifierBox',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: handlePersonShowingHealthCard,
            isIssuer: false
        });
    }, strings.clickMeButtonTextPerformStep, true);
}

function prepareLastStep() {
    utils.setPersonImage('#personImageContainer', 'img/ico_user-laptop-talk-left.png', 'end', 'start');
    utils.dimVerifierBoxLogo();
    utils.undimIssuerBoxLogo();
    utils.setIssuerBox([{
        id: 'docInHandHealthCardProv2',
        text: strings.documentsInHand.healthCardProv2,
        imageUrl: 'img/ico_health-card-prov2.png'
    }]);

    utils.logMessage2('#issuerLog', strings.logs.issueHealthCard, 5);

    utils.enableDragAndDrop({
        draggableId: '#docInHandHealthCardProv2',
        droppableId: '#healthCardDroppable',
        containment: '#bodyContent',
        hoverClass: 'droppable-hover',
        dropHandler: finishDemo,
        isIssuer: true
    });
}

function finishDemo() {
    utils.removeTooltips();
    utils.disableDragAndDrop({
        draggableId: '#docInHandHealthCardProv2',
        droppableId: '#healthCardDroppable',
        isIssuer: true
    });

    $('#docInHandHealthCardProv2').remove();
    $('#healthCardDroppable').remove();
    $('#issuerDropZone').empty();

    utils.addDocInHandsFromIssuerBoxDropZone({
        id: 'docInHandsHealthCardProv2',
        text: strings.documentsInHand.healthCardProv2,
        imageUrl: 'img/ico_health-card-prov2.png'
    });

    utils.showRegistryInteraction(true, function () {

        utils.logMessage2('#holderLog', strings.logs.storeHealthCard, 2);

        utils.setStepOff('#stepBox5_step');
        $('#personImage').animate({ opacity: '1' });

        setTimeout(function () {
            utils.showThankYouMessage(true);
        }, 1000);
    });
}

export { init };
