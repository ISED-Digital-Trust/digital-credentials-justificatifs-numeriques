import { strings } from '../strings.js';
import * as utils from '../utils.js';

function init() {
    utils.displayRegistryArrows(false, false);
    fillDocsInHand();
    fillSteps();
    prepareFirstStep();
}

function fillDocsInHand() {
    utils.setDocumentsInHand([
        {
            id: 'docInHandDriversLicense',
            text: strings.documentsInHand.driversLicense,
            imageUrl: 'img/ico_drivers-license.png'
        },
        {
            id: 'docInHandCarRegistration',
            text: strings.documentsInHand.carRegistration,
            imageUrl: 'img/ico_car-registration.png'
        }
    ], true, 'carInsuranceDroppable');
}

function fillSteps() {
    utils.setSteps([
        {
            id: 'stepConnecToInsuranceCo',
            text: strings.steps.stepConnecToInsuranceCo
        },
        {
            id: 'stepRequestCarInsurance',
            text: strings.steps.stepRequestCarInsurance
        },
        {
            id: 'stepShowDriversLicense',
            text: strings.steps.stepShowDriversLicense
        },
        {
            id: 'stepShowCarRegistration',
            text: strings.steps.stepShowCarRegistration
        },
        {
            id: 'stepReceiveCarInsurance',
            text: strings.steps.stepReceiveCarInsurance
        }
    ], strings.steps.descriptions.getInsurance.stepConnecToInsuranceCo);
}

function prepareFirstStep() {
    utils.setPersonBeginImage(true);
    utils.dimIssuerBoxLogo();
    utils.enableStartDemoClick(function () {
        utils.setPersonImage('#personImageContainer', 'img/ico_user-laptop-talk-right.png', 'center', 'end');
        hanlePersonVisitingInsuranceCompany();
    }, strings.clickMeButtonTextVisit, false);
}

function hanlePersonVisitingInsuranceCompany() {
    utils.setStepOff('#stepConnecToInsuranceCo_step');
    utils.setStepOn('#stepRequestCarInsurance_step', '2', strings.steps.descriptions.getInsurance.stepRequestCarInsurance);

    utils.enableStartDemoClick(function () {
        utils.setStepOff('#stepRequestCarInsurance_step');
        utils.setStepOn('#stepShowDriversLicense_step', '3', strings.steps.descriptions.getInsurance.stepShowDriversLicense);

        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 1);

        $('#driversLicenseVerifierBox').animate({ opacity: '1' });
        utils.enableDragAndDrop({
            draggableId: '#docInHandDriversLicense',
            droppableId: '#driversLicenseVerifierBox',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: handlePersonShowingDriversLicense,
            isIssuer: false
        });
    }, strings.clickMeButtonTextPerformStep, true);
}

function handlePersonShowingDriversLicense() {
    $('#veriferDragAndDropHint').addClass('invisible');

    $('#driversLicenseVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandDriversLicenseVerifierBox',
        text: strings.documentsInHand.driversLicense,
        imageUrl: 'img/ico_drivers-license.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandDriversLicense',
            droppableId: '#driversLicenseVerifierBox',
            isIssuer: false
        });

        utils.setStepOff('#stepShowDriversLicense_step');
        utils.setStepOn('#stepShowCarRegistration_step', '4', strings.steps.descriptions.getInsurance.stepShowCarRegistration);

        utils.logMessage('#holderLog', strings.logs.consentToShareId);
        utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);
        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 2);

        $('#carRegistrationVerifierBox').animate({ opacity: '1' });
        utils.enableDragAndDrop({
            draggableId: '#docInHandCarRegistration',
            droppableId: '#carRegistrationVerifierBox',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: handlePersonShowingCarRegistration,
            isIssuer: false
        });
    });
}

function handlePersonShowingCarRegistration() {
    $('#veriferDragAndDropHint').addClass('invisible');

    $('#carRegistrationVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandCarRegistration',
        text: strings.documentsInHand.carRegistration,
        imageUrl: 'img/ico_car-registration.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.logMessage('#holderLog', strings.logs.consentToShareId);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandCarRegistration',
            droppableId: '#carRegistrationVerifierBox',
            isIssuer: false
        });

        utils.setStepOff('#stepShowCarRegistration_step');
        utils.setStepOn('#stepReceiveCarInsurance_step', '5', strings.steps.descriptions.getInsurance.stepReceiveCarInsurance);

        utils.logMessage2('#issuerLog', strings.logs.issueCarInsurance, 8);
        utils.setPersonImage('#personImageContainer', 'img/ico_user-laptop-talk-left.png', 'end', 'start');
        utils.dimVerifierBoxLogo();
        utils.undimIssuerBoxLogo();
        utils.setIssuerBox([
            {
                id: 'docInHandCarInsurance',
                text: strings.documentsInHand.carInsurance,
                imageUrl: 'img/ico_proof-insurance.png'
            }
        ]);
        $('#carInsuranceDroppable').animate({ opacity: '1' });

        utils.enableDragAndDrop({
            draggableId: '#docInHandCarInsurance',
            droppableId: '#carInsuranceDroppable',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: finishDemo,
            isIssuer: true
        });
    });
}

function finishDemo() {
    utils.disableDragAndDrop({
        draggableId: '#docInHandCarInsurance',
        droppableId: '#carInsuranceDroppable',
        isIssuer: true
    });

    utils.logMessage2('#holderLog', strings.logs.storeCarInsurance, 2);

    $('#carInsuranceDroppable').remove();
    $('#issuerDropZone').empty();

    utils.addDocInHandsFromIssuerBoxDropZone({
        id: 'docInHandsProofOfInsurance',
        text: strings.documentsInHand.carInsurance,
        imageUrl: 'img/ico_proof-insurance.png'
    });

    utils.showRegistryInteraction(true, function () {
        utils.setStepOff('#stepReceiveCarInsurance_step');
        utils.showThankYouMessage(true);
    });
}

export { init };