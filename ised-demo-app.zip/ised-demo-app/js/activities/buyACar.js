import { strings } from '../strings.js';
import * as utils from '../utils.js';

function init() {
    utils.displayRegistryArrows(false, false);
    utils.initVerifierBox('img/ico_car-dealer.png', strings.domain.carDealer);
    utils.initIssuerBox('img/ico_car-dealer.png', strings.domain.carDealer);
    fillDocsInHand();
    fillSteps();
    prepareFirstStep();
}

function fillDocsInHand() {
    utils.setDocumentsInHand([
        {
            id: 'docInHandDriversLicense',
            text: strings.documentsInHand.driversLicense,
            imageUrl: 'img/ico_drivers-license.png'
        }
    ], true, 'proofOfOwnershipDroppable');
}

function fillSteps() {
    utils.setSteps([
        {
            id: 'stepVisitCarDealer',
            text: strings.steps.stepVisitCarDealer
        },
        {
            id: 'stepPresentDriversLicense',
            text: strings.steps.stepPresentDriversLicense
        },
        {
            id: 'stepReceiveCarProofOfOwnership',
            text: strings.steps.stepReceiveCarProofOfOwnership
        }
    ], strings.steps.descriptions.buyACar.stepVisitCarDealer);
}

function prepareFirstStep() {
    utils.setPersonBeginImage(false);
    utils.dimIssuerBoxLogo();
    utils.enableStartDemoClick(function () {
        utils.setPersonImage('#personImageContainer', 'img/ico_talk-right.png', 'center', 'end');
        handlePersonVisitingCarDealer();
    }, strings.clickMeButtonTextVisit, true);
}

function handlePersonVisitingCarDealer() {
    setTimeout(function () {
        utils.setStepOff('#stepVisitCarDealer_step');
        utils.setStepOn('#stepPresentDriversLicense_step', '2', strings.steps.descriptions.buyACar.stepPresentDriversLicense);

        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 1);

        $('#driversLicenseVerifierBox').animate({ opacity: '1' });
        utils.enableDragAndDrop({
            draggableId: '#docInHandDriversLicense',
            droppableId: '#driversLicenseVerifierBox',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: handlePersonShowingDriversLicense,
            isIssuer: false
        });
    }, 2000)
}

function handlePersonShowingDriversLicense() {
    $('#veriferDragAndDropHint').addClass('invisible');

    $('#driversLicenseVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandDriversLicenseVerifierBox',
        text: strings.documentsInHand.driversLicense,
        imageUrl: 'img/ico_drivers-license.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.logMessage('#holderLog', strings.logs.consentToShareId);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandDriversLicense',
            droppableId: '#driversLicenseVerifierBox',
            isIssuer: false
        });

        utils.setStepOff('#stepPresentDriversLicense_step');
        utils.setStepOn('#stepReceiveCarProofOfOwnership_step', '3', strings.steps.descriptions.buyACar.stepReceiveCarProofOfOwnership);

        $('#docInHandDriversLicense').animate({ top: '', left: '' });
        utils.setPersonImage('#personImageContainer', 'img/ico_talk-left.png', 'end', 'start');

        utils.displayRegistryArrows(false, false);
        utils.setIssuerBox([
            {
                id: 'docInHandProofOfCarOwnership',
                text: strings.documentsInHand.proofOfOwnerShip,
                imageUrl: 'img/ico_proof-ownership.png'
            }
        ]);
        $('#proofOfOwnershipDroppable').animate({ opacity: '1' });

        utils.logMessage2('#issuerLog', strings.logs.issueProofOfOwnership, 4);

        utils.enableDragAndDrop({
            draggableId: '#docInHandProofOfCarOwnership',
            droppableId: '#proofOfOwnershipDroppable',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: finishDemo,
            isIssuer: true
        });
    });
}

function finishDemo() {
    utils.disableDragAndDrop({
        draggableId: '#docInHandProofOfCarOwnership',
        droppableId: '#proofOfOwnershipDroppable',
        isIssuer: true
    });

    utils.showRegistryInteraction(true, function () {

        utils.logMessage2('#holderLog', strings.logs.storeProofOfOwnership, 2);

        $('#driversLicenseDroppable').remove();
        $('#issuerDropZone').empty();
        $('#personImageSpeakToIssuer').animate({ opacity: '0' });
        $('#personImageSpeakToVerifier').animate({ opacity: '0' });
        $('#personImage').animate({ opacity: '1' });

        utils.addDocInHandsFromIssuerBoxDropZone({
            id: 'docInHandsProofOfOwnership',
            text: strings.documentsInHand.carProofOfOwnership,
            imageUrl: 'img/ico_proof-ownership.png'
        });

        utils.setStepOff('#stepReceiveCarProofOfOwnership_step');

        utils.showThankYouMessage();
    });
}

export { init };
