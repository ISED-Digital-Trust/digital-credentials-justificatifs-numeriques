import { strings } from '../strings.js';
import * as utils from '../utils.js';

function init() {
    utils.displayRegistryArrows(false, false);
    fillDocsInHand();
    fillSteps();
    prepareFirstStep();

}

function fillDocsInHand() {
    utils.setDocumentsInHand([
        {
            id: 'docInHandTestResults',
            text: strings.documentsInHand.testResults,
            imageUrl: 'img/ico_driving-test-results.png'
        },
        {
            id: 'docInHandBirthCertificate',
            text: strings.documentsInHand.birthCertificate,
            imageUrl: 'img/ico_birth-certificate.png'
        },
        {
            id: 'docInHandProofOfResidence',
            text: strings.documentsInHand.proofOfResidence,
            imageUrl: 'img/ico_proof-residence.png'
        }
    ]);
}

function fillSteps() {
    utils.setSteps([
        {
            name: 'visitMotorVehicleOffice',
            id: 'stepVisitMotorVehicleOffice',
            text: strings.steps.stepVisitMotorVehicleOffice
        },
        {
            name: 'requestDriverLicense',
            id: 'stepRequestDriverLicense',
            text: strings.steps.stepRequestDriverLicense
        },
        {
            name: 'presentBirthCertificate',
            id: 'stepPresentBirthCertificate',
            text: strings.steps.stepPresentBirthCertificate
        },
        {
            name: 'presentProofOfResidency',
            id: 'stepPresentProofOfResidency',
            text: strings.steps.stepPresentProofOfResidency
        },
        {
            name: 'receiveDriversLicense',
            id: 'stepReceiveDriversLicense',
            text: strings.steps.stepReceiveDriversLicense
        }
    ], strings.steps.descriptions.getDriverLicense.stepVisitMotorVehicleOffice);
}

function handlePersonVisitingVehicleOffice() {
    utils.setStepOff('#stepVisitMotorVehicleOffice_step');
    utils.setStepOn('#stepRequestDriverLicense_step', '2', strings.steps.descriptions.getDriverLicense.stepRequestDriverLicense);

    utils.enableStartDemoClick(function () {
        utils.setStepOff('#stepRequestDriverLicense_step');
        utils.setStepOn('#stepPresentBirthCertificate_step', '3', strings.steps.descriptions.getDriverLicense.stepPresentBirthCertificate);

        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 1);

        var imgElement = utils.getDocumentImgElement({
            id: 'docInHandBirthCertificateVerifierBox',
            text: strings.documentsInHand.testResults,
            imageUrl: 'img/ico_driving-test-results.png'
        });
        imgElement.appendTo('#motorVehicleOfficeDropZone');
        $('#docInHandBirthCertificateVerifierBox').tooltip('show');
        setTimeout(function () {
            $('#docInHandBirthCertificateVerifierBox').tooltip('hide');
            $('#docInHandBirthCertificateVerifierBox').tooltip({ trigger: 'hover' });
            utils.removeTooltips();
            prepareThirdStep();
        }, 2000);

    }, strings.clickMeButtonTextPerformStep, true);

}

function handlePersonShowingBirthCertificate(event, ui) {
    $('#veriferDragAndDropHint').addClass('invisible');
    utils.logMessage('#holderLog', strings.logs.consentToShareId);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    $('#birthCertificateVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandBirthCertificateVerifierBox',
        text: strings.documentsInHand.birthCertificate,
        imageUrl: 'img/ico_birth-certificate.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandBirthCertificate',
            droppableId: '#birthCertificateVerifierBox',
            isIssuer: false
        });

        utils.setStepOff('#stepPresentBirthCertificate_step');
        utils.setStepOn('#stepPresentProofOfResidency_step', '4', strings.steps.descriptions.getDriverLicense.stepPresentProofOfResidency);
        utils.logMessage('#verifierLog', strings.logs.requestProofOfResidency);

        prepareFourthStep();
    });
}

function handlePersonShowingProofOfResidence(event, ui) {
    $('#veriferDragAndDropHint').addClass('invisible');
    $('#proofOfResidenceVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandProofOfResidenceVerifierBox',
        text: strings.documentsInHand.proofOfResidence,
        imageUrl: 'img/ico_proof-residence.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandProofOfResidence',
            droppableId: '#proofOfResidenceVerifierBox',
            isIssuer: false
        });

        utils.setStepOff('#stepPresentProofOfResidency_step');
        utils.setStepOn('#stepReceiveDriversLicense_step', '5', strings.steps.descriptions.getDriverLicense.stepReceiveDriversLicense);

        utils.setPersonImage('#personImageContainer', 'img/ico_talk-left.png', 'end', 'start');

        utils.logMessage2('#holderLog', strings.logs.showUtilityBill, 2);

        utils.dimVerifierBoxLogo();
        utils.undimIssuerBoxLogo();

        utils.logMessage2('#issuerLog', strings.logs.issueDriversLicense, 6);

        utils.setIssuerBox([
            {
                id: 'docInHandDriverLicense',
                text: strings.documentsInHand.driversLicense,
                imageUrl: 'img/ico_drivers-license.png'
            }
        ]);
        $('#driversLicenseDroppable').animate({ opacity: '1' });

        utils.enableDragAndDrop({
            draggableId: '#docInHandDriverLicense',
            droppableId: '#driversLicenseDroppable',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: finishDemo,
            isIssuer: true
        });
    });
}

function prepareFirstStep() {
    utils.setPersonBeginImage(false);
    utils.dimIssuerBoxLogo();
    utils.enableStartDemoClick(function () {
        utils.setPersonImage('#personImageContainer', 'img/ico_talk-right.png', 'center', 'end');
        handlePersonVisitingVehicleOffice();
    }, strings.clickMeButtonTextVisit, false);
}

function prepareThirdStep() {
    utils.enableDragAndDrop({
        draggableId: '#docInHandBirthCertificate',
        droppableId: '#birthCertificateVerifierBox',
        containment: '#bodyContent',
        hoverClass: 'droppable-hover',
        dropHandler: handlePersonShowingBirthCertificate,
        isIssuer: false
    });
}

function prepareFourthStep() {
    $('#proofOfResidenceVerifierBox').animate({ opacity: '1' });
    utils.enableDragAndDrop({
        draggableId: '#docInHandProofOfResidence',
        droppableId: '#proofOfResidenceVerifierBox',
        containment: '#bodyContent',
        hoverClass: 'droppable-hover',
        dropHandler: handlePersonShowingProofOfResidence,
        isIssuer: false
    });
}

function finishDemo() {
    utils.disableDragAndDrop({
        draggableId: '#docInHandDriverLicense',
        droppableId: '#driversLicenseDroppable',
        isIssuer: true
    });

    $('#driversLicenseDroppable').remove();
    $('#issuerDropZone').empty();

    utils.addDocInHandsFromIssuerBoxDropZone({
        id: 'docInHandsDriversLicense',
        text: strings.documentsInHand.driversLicense,
        imageUrl: 'img/ico_drivers-license.png'
    });

    utils.showRegistryInteraction(true, function () {
        utils.setStepOff('#stepReceiveDriversLicense_step');

        utils.logMessage('#holderLog', '&nbsp;');
        utils.logMessage('#holderLog', strings.logs.storeDriversLicense);

        utils.showThankYouMessage();
    });
}

export { init };