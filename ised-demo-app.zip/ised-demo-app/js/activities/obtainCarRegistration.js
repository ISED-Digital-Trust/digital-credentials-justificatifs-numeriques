import { strings } from '../strings.js';
import * as utils from '../utils.js';

function init() {
    utils.displayRegistryArrows(false, false);
    fillDocsInHand();
    fillSteps();
    prepareFirstStep();
}

function fillDocsInHand() {
    utils.setDocumentsInHand([
        {
            id: 'docInHandcarProofOfOwnership',
            text: strings.documentsInHand.proofOfOwnerShip,
            imageUrl: 'img/ico_proof-ownership.png'
        }
    ], true, 'carRegistrationDroppable');
}

function fillSteps() {
    utils.setSteps([
        {
            id: 'stepConnecToMotorVehicleOffice',
            text: strings.steps.stepConnecToMotorVehicleOffice
        },
        {
            id: 'stepRequestToRegisterTheCar',
            text: strings.steps.stepRequestToRegisterTheCar
        },
        {
            id: 'stepShowProofOfOwnership',
            text: strings.steps.stepShowProofOfOwnership
        },
        {
            id: 'stepReceiveCarRegistration',
            text: strings.steps.stepReceiveCarRegistration
        }
    ], strings.steps.descriptions.obtainCarRegistration.stepConnecToMotorVehicleOffice);
}

function prepareFirstStep() {
    utils.setPersonBeginImage(true);
    utils.dimIssuerBoxLogo();
    utils.enableStartDemoClick(function () {
        utils.setPersonImage('#personImageContainer', 'img/ico_user-laptop-talk-right.png', 'center', 'end');
        hanlePersonVisitingMotorVehicleOffice();
    }, strings.clickMeButtonTextVisit, false);
}

function hanlePersonVisitingMotorVehicleOffice() {
    utils.setStepOff('#stepConnecToMotorVehicleOffice_step');
    utils.setStepOn('#stepRequestToRegisterTheCar_step', '2', strings.steps.descriptions.obtainCarRegistration.stepRequestToRegisterTheCar);

    utils.enableStartDemoClick(function () {
        utils.setStepOff('#stepRequestToRegisterTheCar_step');
        utils.setStepOn('#stepShowProofOfOwnership_step', '3', strings.steps.descriptions.obtainCarRegistration.stepShowProofOfOwnership);

        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);
        utils.logMessage2('#holderLog', strings.logs.requestForId, 1);

        $('#proofOfOwnershipVerifierBox').animate({ opacity: '1' });
        utils.enableDragAndDrop({
            draggableId: '#docInHandcarProofOfOwnership',
            droppableId: '#proofOfOwnershipVerifierBox',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: handlePersonShowingProofOfOwnership,
            isIssuer: false
        });
    }, strings.clickMeButtonTextPerformStep, true);
}

function handlePersonShowingProofOfOwnership() {
    $('#veriferDragAndDropHint').addClass('invisible');

    $('#proofOfOwnershipVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandcarProofOfOwnershipVerifierBox',
        text: strings.documentsInHand.proofOfOwnerShip,
        imageUrl: 'img/ico_proof-ownership.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.logMessage('#holderLog', strings.logs.consentToShareId);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandcarProofOfOwnership',
            droppableId: '#proofOfOwnershipVerifierBox',
            isIssuer: false
        });

        utils.setStepOff('#stepShowProofOfOwnership_step');
        utils.setStepOn('#stepReceiveCarRegistration_step', '4', strings.steps.descriptions.obtainCarRegistration.stepReceiveCarRegistration);

        utils.logMessage2('#issuerLog', strings.logs.issueCarRegistration, 4);

        utils.setPersonImage('#personImageContainer', 'img/ico_user-laptop-talk-left.png', 'end', 'start');
        utils.dimVerifierBoxLogo();
        utils.undimIssuerBoxLogo();


        utils.displayRegistryArrows(false, false);
        utils.setIssuerBox([
            {
                id: 'docInHandCarRegistration',
                text: strings.documentsInHand.carRegistration,
                imageUrl: 'img/ico_car-registration.png'
            }
        ]);
        $('#carRegistrationDroppable').animate({ opacity: '1' });

        utils.enableDragAndDrop({
            draggableId: '#docInHandCarRegistration',
            droppableId: '#carRegistrationDroppable',
            containment: '#bodyContent',
            hoverClass: 'droppable-hover',
            dropHandler: finishDemo,
            isIssuer: true
        });
    });
}

function finishDemo() {
    utils.disableDragAndDrop({
        draggableId: '#docInHandCarRegistration',
        droppableId: '#carRegistrationDroppable',
        isIssuer: true
    });

    utils.logMessage2('#holderLog', strings.logs.storeCarRegistration, 2);

    $('#carRegistrationDroppable').remove();
    $('#issuerDropZone').empty();
    $('#personImageSpeakToIssuer').animate({ opacity: '0' });
    $('#personImageSpeakToVerifier').animate({ opacity: '0' });
    $('#personImage').animate({ opacity: '1' });

    utils.addDocInHandsFromIssuerBoxDropZone({
        id: 'docInHandsCarRegistration',
        text: strings.documentsInHand.carRegistration,
        imageUrl: 'img/ico_car-registration.png'
    });

    utils.showRegistryInteraction(true, function () {
        utils.setStepOff('#stepReceiveCarRegistration_step');
        utils.showThankYouMessage(true);
    });
}

export { init };