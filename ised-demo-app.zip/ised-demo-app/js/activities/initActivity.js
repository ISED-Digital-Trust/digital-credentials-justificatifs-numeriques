import * as utils from '../utils.js';
import { init as initGetDriversLicense } from './getDriversLicense.js';
import { init as initCompleteDriverTest } from './completeDriverTest.js';
import { init as initRelocate } from './relocate.js';
import { init as initBuyACar } from './buyACar.js';
import { init as initObtainCarRegistration } from './obtainCarRegistration.js'
import { init as initGetInsurance } from './getInsurance.js'

var currentActivity = '';

function initActivity(activityId) {
    utils.resetLogs();
    hideWorkingZone();

    $('#restartButton').addClass('d-none');
    $('#goButton').removeClass('d-none');
    $('#summaryModal .modal-footer').removeClass('d-none');
    $('#veriferDragAndDropHint').addClass('invisible');
    $('#issuerDragAndDropHint').addClass('invisible');

    if (activityId === 'makeAChoice') {
        $('#demoSummary').text('');
        $('#demoSummaryIdLingo').text('');
        $('#goButton').attr('disabled', true);
        window.scrollTo(0, 0);
        return;
    }

    currentActivity = activityId;

    $('#restartButton').off('click').on('click', function () {
        beginActivity();
    });

    $('#goButton').attr('disabled', false);
    $('#goButton').off('click');
    $('#goButton').on('click', function () {
        $('#summaryModal').modal('show');
        $('#startDemoBtn').off('click');
        $('#startDemoBtn').on('click', function () {
            $('#summaryModal').modal('hide');
            beginActivity();
        });
    });
}

function showWorkingZone() {
    $('#stepperRow').removeClass('invisible');
    $('#actionsContainer').removeClass('invisible');
    $('#logsRow').removeClass('invisible');
}

function hideWorkingZone() {
    $('#stepperRow').addClass('invisible');
    $('#actionsContainer').addClass('invisible');
    $('#logsRow').addClass('invisible');
}

function resetIssuerBox() {
    $('#issuerDropZone').empty();
    $('#issuerBoxHeaderTop').addClass('invisible');
}

function resetVerifierBox() {
    $('#motorVehicleOfficeDropZone').empty();
    $('#motorVehicleOfficeTop').addClass('invisible');
}

function restartActivity() {
    console.log('Restarting activity', currentActivity);
    beginActivity(currentActivity);
}

function beginActivity() {
    showWorkingZone();
    utils.resetLogs();
    utils.positionPersonImage();

    $('#issuerDragAndDropHint').addClass('invisible');
    $('#veriferDragAndDropHint').addClass('invisible');

    $('.actions').removeClass('no-steps').addClass('with-steps');
    $('.step').removeClass('on');
    $('#goButton').addClass('d-none');
    $('#restartButton').removeClass('d-none');

    $('#docInHandsContainer div').empty();
    resetIssuerBox();
    resetVerifierBox();

    switch (currentActivity) {
        case 'completeDriverTest':
            initCompleteDriverTest();
            break;

        case 'getDriverLicense':
            initGetDriversLicense();
            break;

        case 'buyACar':
            initBuyACar();
            break;

        case 'obtainCarRegistration':
            initObtainCarRegistration();
            break;

        case 'getInsurance':
            initGetInsurance();
            break;

        case 'relocate':
            initRelocate();
            break;

        default:
            alert(`Activity ${activityId} not implemented yet.`);
            break;
    }
}

export { initActivity };