import { strings } from '../strings.js';
import * as utils from '../utils.js';


function init() {
    // Stop the possibly running car animation
    $('#movingCar').stop(true, false);
    utils.displayRegistryArrows(false, false);
    fillDocsInHand();
    fillSteps();
    prepareFirstStep();
}

function fillDocsInHand() {
    utils.setDocumentsInHand([
        {
            id: 'docInHandBirthCertificate',
            text: strings.documentsInHand.birthCertificate,
            imageUrl: 'img/ico_birth-certificate.png'
        }
    ], false);
}

function fillSteps() {
    utils.setSteps([
        {
            id: 'stepVisitMotorVehicleOffice',
            text: strings.steps.stepVisitMotorVehicleOffice
        },
        {
            id: 'stepRequestToChallenge',
            text: strings.steps.stepRequestToChallenge
        },
        {
            id: 'stepPresentBirthCertificate',
            text: strings.steps.stepPresentBirthCertificate
        },
        {
            id: 'stepDoTest',
            text: strings.steps.stepDoTest
        },
        {
            id: 'stepGetYourResults',
            text: strings.steps.stepGetYourResults
        }
    ], strings.steps.descriptions.completeDriverTest.stepVisitMotorVehicleOffice);
}

function prepareFirstStep() {
    utils.setPersonBeginImage(false);
    utils.dimIssuerBoxLogo();
    utils.enableStartDemoClick(function () {
        utils.setPersonImage('#personImageContainer', 'img/ico_talk-right.png', 'center', 'end');
        handlePersonVisitingVehicleOffice();
    }, strings.clickMeButtonTextVisit, false);
}

function prepareThirdStep() {
    utils.logMessage2('#holderLog', strings.logs.requestForId, 1);

    utils.enableDragAndDrop({
        draggableId: '#docInHandBirthCertificate',
        droppableId: '#birthCertificateVerifierBox',
        containment: '#bodyContent',
        hoverClass: 'droppable-hover',
        dropHandler: handlePersonShowingBirthCertificate,
        isIssuer: false
    });
}

function handlePersonVisitingVehicleOffice(event, ui) {
    utils.setStepOff('#stepVisitMotorVehicleOffice_step');
    utils.setStepOn('#stepRequestToChallenge_step', '2', strings.steps.descriptions.completeDriverTest.stepRequestToChallenge);

    utils.enableStartDemoClick(function () {
        utils.setStepOff('#stepRequestToChallenge_step');
        utils.setStepOn('#stepPresentBirthCertificate_step', '3', strings.steps.descriptions.completeDriverTest.stepPresentBirthCertificate);
        utils.logMessage('#verifierLog', strings.logs.requestDigitalId);

        prepareThirdStep();
    }, strings.clickMeButtonTextPerformStep, true);
}

function handlePersonShowingBirthCertificate(event, ui) {
    utils.logMessage('#holderLog', strings.logs.consentToShareId);
    utils.logMessage2('#verifierLog', strings.logs.verifyId, 2);

    $('#veriferDragAndDropHint').addClass('invisible');

    $('#birthCertificateVerifierBox').remove();
    var imgElement = utils.getDocumentImgElement({
        id: 'docInHandBirthCertificateVerifierBox',
        text: strings.documentsInHand.birthCertificate,
        imageUrl: 'img/ico_birth-certificate.png'
    });
    imgElement.appendTo('#motorVehicleOfficeDropZone');

    utils.showRegistryInteraction(false, function () {
        utils.disableDragAndDrop({
            draggableId: '#docInHandBirthCertificate',
            droppableId: '#birthCertificateVerifierBox',
            isIssuer: false
        });

        utils.setStepOff('#stepPresentBirthCertificate_step');
        utils.setStepOn('#stepDoTest_step', '4', strings.steps.descriptions.completeDriverTest.stepDoTest);

        setTimeout(function () {
            $('<div><img src="img/ico_vehicule-on.png" id="movingCar" style="position: relative;z-index: 100; opacity: 0"/></div>').appendTo('#motorVehicleOfficeDropZone');
            utils.logMessage2('#holderLog', strings.logs.doingDrivingTest, 1);

            $('#personImage').animate({ opacity: '0' }, "slow");
            $('#movingCar').animate({ opacity: '1' }, "slow");
            $('#movingCar').animate({ left: '+=150px' }, "slow");
            $('#movingCar').animate({ top: '-=300px' }, "slow");
            $('#movingCar').animate({ left: '-=1400px' }, 2000);
            $('#movingCar').animate({ top: '+=450px' }, 1500);
            $('#movingCar').animate({ left: '+=1300px' }, 2000);
            $('#movingCar').animate({ top: '-=175px' }, "slow");
            $('#movingCar').animate({ left: '-=150px' }, "slow");
            $('#movingCar').animate({ opacity: '0' }, "slow", function () {
                $('#personImage').animate({ opacity: '1' }, "slow");
                utils.enableStartDemoClick(function () {
                    utils.logMessage2('#holderLog', strings.logs.doneDrivingTest, 0);

                    utils.setStepOff('#stepDoTest_step');
                    utils.setStepOn('#stepGetYourResults_step', '5', strings.steps.descriptions.completeDriverTest.stepGetYourResults);

                    utils.logMessage2('#issuerLog', strings.logs.issueTestResults, 6);

                    utils.setIssuerBox([
                        {
                            id: 'docInHandTestResults',
                            text: strings.documentsInHand.testResults,
                            imageUrl: 'img/ico_driving-test-results.png'
                        }
                    ]);

                    $('#testResultsDroppable').animate({ opacity: '1' });

                    utils.setPersonImage('#personImageContainer', 'img/ico_talk-left.png', 'end', 'start');

                    utils.enableDragAndDrop({
                        draggableId: '#docInHandTestResults',
                        droppableId: '#testResultsDroppable',
                        containment: '#bodyContent',
                        hoverClass: 'droppable-hover',
                        dropHandler: finishDemo,
                        isIssuer: true
                    });

                }, strings.clickMeButtonTextPerformStep, true);
            });
        }, 2000);
    });
}

function finishDemo() {
    utils.disableDragAndDrop({
        draggableId: '#docInHandTestResults',
        droppableId: '#testResultsDroppable',
        isIssuer: true
    });

    $('#testResultsDroppable').remove();
    $('#issuerDropZone').empty();

    utils.addDocInHandsFromIssuerBoxDropZone({
        id: 'docInHandsTestResults',
        text: strings.documentsInHand.testResults,
        imageUrl: 'img/ico_driving-test-results.png'
    });

    utils.showRegistryInteraction(true, function () {
        utils.setStepOff('#stepGetYourResults_step');

        utils.logMessage2('#holderLog', strings.logs.storeTestResuls, 1);

        utils.showThankYouMessage();
    });
}

export { init };