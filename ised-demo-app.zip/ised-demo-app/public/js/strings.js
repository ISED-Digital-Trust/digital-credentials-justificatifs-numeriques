let frStrings = {
    documentTitle: 'Portail Éducatif',
    restartButtonText: 'Recommencer',
    goButtonText: 'Allons-y!',
    summaryModalButtonText: 'Commencer',
    issuerBoxTitle: 'Émetteur',
    verifierBoxTitle: 'Vérificateur',
    holderBoxTitle: 'Titulaire',
    clickMeButtonTextVisit: 'Cliquez sur moi pour commencer!',
    clickMeButtonTextConnection: 'Cliquez sur moi pour établir la connexion!',
    clickMeButtonTextPerformStep: 'Cliquez ici pour continuer',
    issuerLogBoxTitle: 'Journal de l\'émetteur',
    holderLogBoxTitle: 'Journal du titulaire',
    verifierLogBoxTitle: 'Journal du vérificateur',
    noLogEntryText: '* Aucun journal *',
    resilientRegistryInfraText: 'Infrastructure de registre résiliente',
    issuingDocumentToRegistry: 'Preuve de délivrance',
    verifyingDocumentAgainstRegistry: 'Vérifier la révocation',
    personBeginImage: 'img/ico_user-40.png',
    scenario: 'Scénario',
    domain: {
        carDealer: 'Concessionnaire automobile',
        digitalGovernment: 'Gouvernement numérique',
        healthMinistry: 'Ministère de la Santé',
        healthMinistryProv1: 'Ministère de la Santé, province 1',
        healthMinistryProv2: 'Ministère de la Santé, province 2',
        insuranceCompany: 'Compagnie d\'assurances',
        motorVehicleOffice: 'Bureau des véhicules automobiles',
        motorVehicleOfficeProv1: 'Bureau des véhicules automobiles province 1',
        motorVehicleOfficeProv2: 'Bureau des véhicules automobiles province 2'
    },
    thankYouModal: {
        titleText: 'Fin de l\'activité',
        bodyText: 'Félicitations! Vous avez terminé l\'activité!',
        closeButtonText: 'Fermer'
    },
    activities: {
        dropdownTitle: 'Quelle activité voulez-vous effectuer?',
        completeDriverTest: 'Passer un examen de conduite en personne (présenter un justificatif numérique)',
        getDriverLicense: 'Obtenir un permis de conduire en personne (présenter plusieurs justificatifs numériques, en recevoir un)',
        buyACar: 'Acheter une voiture en personne (présenter un justificatif numérique, en recevoir un)',
        obtainCarRegistration: 'Obtenir l\'immatriculation d\'un véhicule à distance (présenter un justificatif numérique, en recevoir un) ',
        getInsurance: 'Souscrire une assurance à distance (présenter plusieurs justificatifs numériques, en obtenir un)',
        relocate: 'Changement de province à distance (présenter, délivrer, révoquer et mettre à jour un justificatif numérique)'
    },
    activityIntros: {
        completeDriverTest: `Vous venez de célébrer un anniversaire important... Vous pouvez maintenant demander votre permis de conduire. Tout d'abord, vous devez passer votre examen de conduite. Pour commencer, vous devrez prouver au préposé aux automobiles que vous avez l'âge légal pour conduire.`,

        completeDriverTestIdLingo: `En d'autres termes : Pour être autorisé à passer l'examen de conduite, vous devez d'abord prouver au préposé aux automobiles (vérificateur de justificatifs d'identité) que vous avez l'âge minimum légal (assertion dérivée). Pour ce faire, présentez un justificatif d'identité vérifiable accepté qui atteste que vous avez l'âge légal. L'utilisation d'un justificatif d'identité numérique vous permet de partager les informations minimales requises, précisément (divulgation sélective conformément aux principes de protection de la vie privée dès la conception), que vous avez l'âge légal (assertion dérivée, et/ou preuve à divulgation nulle de connaissance). Vous pouvez procéder en utilisant votre certificat de naissance numérique délivré par le directeur de l'état civil (émetteur de confiance) de la province où vous êtes né.`,

        getDriverLicense: `Tandis que vous êtes encore au bureau des véhicules automobiles, et avec un résultat d'examen de conduite réussi dans votre dossier, vous pouvez maintenant demander à recevoir un permis de conduire.`,

        getDriverLicenseIdLingo: `En d'autres termes : Vous souhaitez recevoir un justificatif qui atteste que vous avez le droit de conduire une voiture. Vous demandez au ministère des Transports (l'émetteur et l'autorité de certification) de vous délivrer un justificatif qui prouve que vous avez le droit de conduire. Par exemple, il peut servir à prouver à un agent lors d'un contrôle routier (vérificateur de justificatifs) que vous avez le droit de conduire.`,

        buyACar: `Avec un permis de conduire valide... Cela signifie que vous pouvez acheter une voiture. Pour conclure la transaction, le concessionnaire doit vérifier que vous avez un permis de conduire valide. Présentez votre permis de conduire au vendeur pour lancer le processus. Une fois la transaction terminée, vous recevrez la preuve de propriété du véhicule indiquant que vous en êtes le propriétaire.`,

        buyACarIdLingo: `En d'autres termes : Avant que le concessionnaire automobile ne transfère la propriété du véhicule à votre nom, le concessionnaire (le vérificateur de justificatifs) demande à voir et à valider votre permis de conduire (justificatif). Une fois que vous avez consenti à partager votre justificatif, le système du concessionnaire peut confirmer que le permis de conduire a été délivré par un émetteur de confiance et que le justificatif n'a pas été révoqué. Ce processus permet également au concessionnaire de recueillir les informations minimales (divulgation sélective) requises pour que le justificatif de la preuve de propriété du véhicule vous soient délivrés.`,

        obtainCarRegistration: `Avec la preuve de propriété, vous pouvez maintenant demander l'immatriculation de votre véhicule au ministère des Transports. Présentez votre preuve de propriété sur le site internet du bureau des véhicules automobiles pour lancer le processus. Une fois la procédure terminée, vous recevrez l'immatriculation de votre voiture.`,

        obtainCarRegistrationIdLingo: `En d'autres termes : À l'aide de la preuve de propriété de votre véhicule, vous pouvez demander au ministère des Transports (émetteur de confiance) de vous délivrer l'immatriculation du véhicule (justificatif). Le bureau des véhicules automobiles (vérificateur de justificatifs) vous demandera de fournir une preuve valide de la propriété de la voiture. Une fois cette preuve validée, le bureau des véhicules automobiles (émetteur de confiance) vous délivrera l'immatriculation de votre véhicule (justificatif).`,

        getInsurance: `Vous avez besoin d'une assurance automobile avant de pouvoir partir avec votre nouvelle voiture. Heureusement, vous pouvez le faire en ligne en présentant un permis de conduire valide et l'immatriculation de la voiture. Une fois le processus terminé, la compagnie d'assurance vous délivrera une preuve d'assurance.`,

        getInsuranceIdLingo: `En d'autres termes : Vous avez maintenant tous les documents nécessaires pour souscrire une assurance automobile à votre nom. Une fois que vous aurez prouvé que vous avez un permis de conduire valide (personne vérifiée, preuve de possession) et l'immatriculation du véhicule (preuve de possession), l'assurance automobile sera souscrite à votre nom par l'assureur de votre choix, un organisme du secteur privé dans votre province de résidence.`,

        relocate: `Vous venez d'obtenir votre diplôme universitaire et vous avez accepté un emploi à l'extérieur de la province. C'est un emploi génial, dans une province qui est également connue pour avoir les services gouvernementaux numériques les plus avancés, qui sont même intégrés au secteur des services financiers et d'assurance. Après avoir signé le bail de votre nouvel appartement, il est maintenant temps de mettre à jour votre permis de conduire, l'immatriculation de votre voiture, carte santé, et votre assurance.`,

        relocateIdLingo: `En d'autres termes : Déménager dans une autre province vous obligera à révoquer, mettre à jour ou remplacer certains justificatifs.`
    },
    credentials: {
        credentialBoxTitle: 'Liste de vérification pour réaliser l\'activité',
        birthCertificate: 'Certificat de naissance',
        utilityBill: 'Facture de service',
        drivingTestResults: 'Résultats de l\'examen de conduite - au dossier',
        healthCard: 'Carte santé',
        driversLicense: 'Permis de conduire',
        carRegistration: 'Immatriculation du véhicule',
        carInsurance: 'Assurance automobile',
        proofOfOwnership: 'Preuve de propriété'
    },
    documentsInHand: {
        documentsInHandBoxTitle: 'Documents en main',
        birthCertificate: 'Certificat de naissance',
        proofOfResidence: 'Preuve de résidence',
        driversLicense: 'Permis de conduire',
        carRegistration: 'Immatriculation du véhicule',
        carProofOfOwnership: 'Preuve de propriété du véhicule',
        healthCard: 'Carte santé',
        driversLicenseProv1: 'Permis de conduire, province 1',
        carRegistrationProv1: 'Immatriculation du véhicule, province 1',
        driversLicenseProv2: 'Permis de conduire, province 2',
        carRegistrationProv2: 'Immatriculation du véhicule, province 2',
        healthCardProv1: 'Carte santé, province 1',
        apartmentLease: 'Bail de l\'appartement',
        carInsurance: 'Assurance automobile',
        healthCardProv2: 'Carte santé, province 2',
        proofOfOwnerShip: 'Preuve de propriété',
        testResults: 'Résultats de l\'examen'
    },
    steps: {
        stepsBoxTitle: 'Étapes pour réaliser <span>l\'activité</span>',
        stepVisitMotorVehicleOffice: 'Visite du bureau des véhicules automobiles',
        stepRequestDriverLicense: 'Demande de permis de conduire',
        stepPresentBirthCertificate: 'Présentation du certificat de naissance',
        stepPresentProofOfResidency: 'Présentation d\'une preuve de résidence',
        stepReceiveDriversLicense: 'Réception du permis de conduire',
        stepRequestToChallenge: 'Demande de contestation',
        stepDoTest: 'Faire l\'examen',
        stepGetYourResults: 'Obtention des résultats de votre examen de conduite',
        stepVisitDigitalGovServiceDesk: 'Visite du centre de services du gouvernement numérique',
        stepRequestNewDriverLicense: 'Demande d\'un nouveau permis de conduire',
        stepShowDriversLicense: 'Présentation du permis de conduire',
        stepShowCarRegistration: 'Présentation de l\'immatriculation du véhicule',
        stepShowCarInsurance: 'Présentation de l\'assurance du véhicule',
        stepReceiveNewDriversLicense: 'Réception d\'un nouveau permis de conduire',
        stepReceiveNewCarRegistration: 'Réception d\'une nouvelle immatriculation du véhicule',
        stepGiveConsentToNotifyInsuranceCompany: 'Consentement à informer la compagnie d\'assurance',
        stepShowHealthCard: 'Présentation de la carte santé',
        stepReceiveNewHealthCard: 'Réception d\'une nouvelle carte santé',
        stepVisitCarDealer: 'Visite d\'un concessionnaire automobile',
        stepPresentDriversLicense: 'Présentation du permis de conduire',
        stepReceiveCarProofOfOwnership: 'Réception de la preuve de propriété du véhicule',
        stepConnecToMotorVehicleOffice: 'Connexion au bureau des véhicules automobiles',
        stepRequestToRegisterTheCar: 'Demande d\'immatriculation du véhicule',
        stepShowProofOfOwnership: 'Présentation d\'une preuve de propriété',
        stepReceiveCarRegistration: 'Réception de l\'immatriculation du véhicule',
        stepConnecToInsuranceCo: 'Connexion à la compagnie d\'assurance',
        stepRequestCarInsurance: 'Demande d\'assurance automobile',
        stepReceiveCarInsurance: 'Réception de l\'assurance automobile',

        descriptions: {
            completeDriverTest: {
                stepVisitMotorVehicleOffice: 'L\'apprenti conducteur (titulaire) se rend au bureau des véhicules automobiles pour passer un examen de conduite',
                stepRequestToChallenge: 'Le bureau des véhicules automobiles (vérificateur) doit vérifier l\'identité et l\'âge. L\'apprenti conducteur (titulaire) doit fournir une preuve de son identité et de son âge',
                stepPresentBirthCertificate: 'L\'apprenti conducteur (titulaire) présente son certificat de naissance à partir de son portefeuille numérique',
                stepDoTest: 'Une fois son identité vérifiée, le conducteur passe (et réussit) l\'examen de conduite',
                stepGetYourResults: 'Le bureau des véhicules automobiles (désormais émetteur) enregistre le résultat de l\'examen de conduite et crée un justificatif attestant de la réussite de l\'examen, puis envoie le justificatif au portefeuille numérique de l\'apprenti conducteur.'
            },
            getDriverLicense: {
                stepVisitMotorVehicleOffice: 'Une fois le résultat de l\'examen de conduite obtenu, l\'apprenti conducteur (titulaire) est prêt à obtenir un permis de conduire.',
                stepRequestDriverLicense: 'L\'apprenti conducteur (titulaire) demande un permis de conduire. Le bureau des véhicules automobiles doit vérifier son éligibilité',
                stepPresentBirthCertificate: 'L\'apprenti conducteur (titulaire) est invité à fournir une preuve de son identité et de son âge, et présente son certificat de naissance à partir de son portefeuille numérique',
                stepPresentProofOfResidency: 'On demande à l\'apprenti conducteur (titulaire) une preuve de résidence, et il présente ce justificatif depuis son portefeuille numérique. Les justificatifs présentés sont vérifiés (vérificateur).',
                stepReceiveDriversLicense: 'Le bureau des véhicules automobiles (désormais émetteur) crée un justificatif du permis de conduire et le délivre au portefeuille numérique de l\'apprenti conducteur.'
            },
            buyACar: {
                stepVisitCarDealer: 'L\'acheteur d\'une voiture (titulaire) se rend chez le concessionnaire automobile (vérificateur) pour acheter un nouveau véhicule. Le vérificateur doit vérifier le permis de conduire et collecter les informations du justificatif vérifiable nécessaires pour délivrer une preuve de propriété',
                stepPresentDriversLicense: 'L\'acheteur de la voiture (titulaire) présente son permis de conduire depuis son portefeuille numérique au concessionnaire (vérificateur). Le justificatif est vérifié',
                stepReceiveCarProofOfOwnership: 'Le concessionnaire automobile ( maintenant un émetteur) crée un justificatif de la preuve de propriété et l\'envoie au portefeuille numérique de l\'acheteur'
            },
            obtainCarRegistration: {
                stepConnecToMotorVehicleOffice: 'Le propriétaire du véhicule (titulaire) se connecte sur le site internet du bureau des véhicules automobiles',
                stepRequestToRegisterTheCar: 'Le propriétaire du véhicule (titulaire) demande l\'immatriculation du véhicule et est invité à présenter sa preuve de propriété sur le site internet du bureau des véhicules automobiles (vérificateur)',
                stepShowProofOfOwnership: 'Le propriétaire du véhicule (titulaire) soumet un justificatif de la preuve de propriété à partir de son portefeuille numérique',
                stepReceiveCarRegistration: 'Le bureau des véhicules automobiles ( maintenant un émetteur) crée un justificatif d\'immatriculation du véhicule et le délivre au portefeuille numérique du propriétaire du véhicule'
            },
            getInsurance: {
                stepConnecToInsuranceCo: 'Le propriétaire du véhicule (titulaire) se connecte au site internet de sa compagnie d\'assurance (vérificateur)',
                stepRequestCarInsurance: 'Le propriétaire du véhicule (titulaire) demande une police d\'assurance pour son véhicule',
                stepShowDriversLicense: 'La compagnie d\'assurance (le vérificateur) demande un permis de conduire et le propriétaire du véhicule (le titulaire) le présente depuis son portefeuille numérique. Le justificatif présenté est vérifié',
                stepShowCarRegistration: 'La compagnie d\'assurance (le vérificateur) demande l\'immatriculation du véhicule et le propriétaire du véhicule (le titulaire) la présente à partir de son portefeuille numérique. Les justificatifs présentés sont vérifiés',
                stepReceiveCarInsurance: 'La compagnie d\'assurance (désormais l\'émetteur) crée un justificatif attestant de la souscription à une assurance et l\'envoie au portefeuille numérique du propriétaire du véhicule'
            },
            relocate: {
                stepVisitDigitalGovServiceDesk: 'Le client (titulaire) visite le site internet des services gouvernementaux de sa nouvelle province et demande à compléter le processus de « déménagement dans notre province »',
                stepRequestNewDriverLicense: 'Le client (titulaire) indique qu\'il souhaite obtenir un nouveau permis de conduire, une nouvelle immatriculation de véhicule et une nouvelle carte santé',
                stepPresentProofOfResidency: 'La province (le vérificateur) demande une preuve de résidence et celle-ci est soumise à partir du portefeuille numérique du titulaire. Le justificatif soumis est vérifié',
                stepShowDriversLicense: 'La province (vérificateur) demande l\'ancien permis de conduire et celui-ci est soumis à partir du portefeuille numérique du titulaire. Le justificatif soumis est vérifié',
                stepShowCarRegistration: 'La province (vérificateur) demande l\'immatriculation précédente du véhicule et celle-ci est soumise à partir du portefeuille numérique du titulaire. Le justificatif soumis est vérifié',
                stepShowCarInsurance: 'La province (vérificateur) demande une preuve d\'assurance et celle-ci est soumise à partir du portefeuille numérique du titulaire. Le justificatif soumis est vérifié',
                stepReceiveNewDriversLicense: 'La province (maintenant un émetteur) crée un nouveau justificatif du permis de conduire et l\'émet dans le portefeuille numérique du client (titulaire). Hors ligne, la province 2 informe la province 1 afin qu\'elle puisse révoquer son justificatif',
                stepReceiveNewCarRegistration: 'La province (maintenant un émetteur) crée un nouveau justificatif d\'immatriculation du véhicule et l\'émet dans le portefeuille numérique du client (titulaire). Hors ligne, la province 2 informe la province 1 afin qu\'elle puisse révoquer son justificatif',
                stepGiveConsentToNotifyInsuranceCompany: 'La province demande et reçoit la permission d\'informer la compagnie d\'assurance du changement d\'adresse. Après avoir reçu le consentement, la province avise la compagnie d\'assurance dans une opération distincte.',
                stepShowHealthCard: 'La province (encore une fois un vérificateur) demande l\'ancienne carte santé et celle-ci est présentée à partir du portefeuille numérique du titulaire. Le justificatif présenté est vérifié',
                stepReceiveNewHealthCard: 'La province (maintenant un émetteur) crée un nouveau justificatif de la carte santé et l\'émet dans le portefeuille numérique du client (titulaire). Hors ligne, la province 2 informe la province 1 afin qu\'elle puisse révoquer son justificatif'
            }
        }
    },
    logs: {
        requestForId: 'Demander l\'identification',
        requestDigitalId: 'Demander l\'identité numérique',
        consentToShareId: 'Consentir au partage de l\'identité',
        verifyId: 'Vérifier l\'identité',
        issueProofOfOwnership: 'Délivrer une preuve de propriété',
        storeProofOfOwnership: 'Conserver la preuve de propriété',
        requestProofOfResidency: 'Demander une preuve de résidence',
        showUtilityBill: 'Présenter une facture de service',
        issueDriversLicense: 'Délivrer le permis de conduire',
        storeDriversLicense: 'Conserver le permis de conduire',
        issueCarInsurance: 'Délivrer une assurance automobile',
        storeCarInsurance: 'Conserver l\'assurance automobile',
        issueCarRegistration: 'Délivrer l\'immatriculation du véhicule',
        storeCarRegistration: 'Conserver l\'immatriculation du véhicule',
        issueTestResults: 'Délivrer les résultats de l\'examen',
        storeTestResuls: 'Conserver les résultats de l\'examen',
        doingDrivingTest: 'Passer l\'examen de conduite',
        doneDrivingTest: 'Test de conduite effectué',
        issueHealthCard: 'Délivrer une carte santé',
        storeHealthCard: 'Conserver la carte santé'
    }
};

let enStrings = {
    documentTitle: 'Education Portal',
    restartButtonText: 'Restart',
    goButtonText: 'Go!',
    summaryModalButtonText: 'Start',
    issuerBoxTitle: 'Issuer',
    verifierBoxTitle: 'Verifier',
    holderBoxTitle: 'Holder',
    clickMeButtonTextVisit: 'Click me to begin!',
    clickMeButtonTextConnection: 'Click me to initiate connection!',
    clickMeButtonTextPerformStep: 'Click here to continue',
    issuerLogBoxTitle: 'Issuer log',
    holderLogBoxTitle: 'Holder log',
    verifierLogBoxTitle: 'Verifier log',
    noLogEntryText: '* No log *',
    resilientRegistryInfraText: 'Resilient registry infrastructure',
    issuingDocumentToRegistry: 'Proof of issuance',
    verifyingDocumentAgainstRegistry: 'Check for revocation',
    personBeginImage: 'img/ico_user-40.png',
    scenario: 'Scenario',
    domain: {
        carDealer: 'Car dealer',
        digitalGovernment: 'Digital government',
        healthMinistry: 'Health ministry',
        healthMinistryProv1: 'Health ministry province 1',
        healthMinistryProv2: 'Health ministry province 2',
        insuranceCompany: 'Insurance company',
        motorVehicleOffice: 'Motor vehicle office',
        motorVehicleOfficeProv1: 'Motor vehicle office province 1',
        motorVehicleOfficeProv2: 'Motor vehicle office province 2'
    },
    thankYouModal: {
        titleText: 'Finishing activity',
        bodyText: 'Congratulations on completing the activity!',
        closeButtonText: 'Close'
    },
    activities: {
        dropdownTitle: 'What activity do you want to complete?',
        completeDriverTest: 'Completing a vehicle driving test in person (present one digital credential)',
        getDriverLicense: 'Get a driver\'s license in person (present multiple digital credentials, receive one)',
        buyACar: 'Buy a vehicle in person (present one digital credential, receive one)',
        obtainCarRegistration: 'Obtain a vehicle registration remotely (present one digital credential, get one)',
        getInsurance: 'Get insurance remotely (present multiple digital credentials, get one)',
        relocate: 'Relocate to a different province remotely (present, issue, revoke, update digital credential)'
    },
    activityIntros: {
        completeDriverTest: `You just celebrated an important birthday… You can now apply for your driver’s license. First things first, you need to pass your driving test. To get
        started, you will need to prove to the Motor Vehicle clerk that you are of
        legal age to drive`,

        completeDriverTestIdLingo: `In other words : To be allowed to take the driving test, you first need to prove to the Motor Vehicle clerk (credential verifier) that you meet the minimum legal age (derived claim). To do so, present an accepted verifiable credential that asserts that you meet the legal age. Using a digital credential allows you to share the minimum information required, specifically (selective disclosure in compliance with Privacy by Design principles), that you are of legal age (derived-claimed, and/or zero-knowledge proof). You can proceed by using your digital birth certificate issued by the vital statistics office (trusted issuer) of the province where you were born.`,

        getDriverLicense: `While still at the motor vehicle office, and with a successful driving test
        result on file, you can now request that a driver’s license be issued.`,

        getDriverLicenseIdLingo: `In other words : You would like to receive a credential that asserts a claim that you have the right to drive a car. You request that a credential be issued, from the ministry of transportation (the issuer and certifying authority), that proves you have the right to drive. As an example, this may be used to prove to an officer at a traffic checkpoint (credential verifier) that you have the right to drive.`,

        buyACar: `With a valid driver’s license… It means you can buy a car. To complete the
        transaction, the dealer needs to verify that you have a valid driver's
        license. Present your driver license to the dealer to get the process started.
        Once completed, you will receive the vehicle proof of ownership showing that you
        are the owner.`,

        buyACarIdLingo: `In other words : Before the car dealer transfers vehicle ownership to your name, the dealer (credential verifier) requests to see and validate your driver's license (credential). Once you consent to share your credential, the dealer’s system can confirm that the driver’s license has been issued by a trusted issuer, and that the credential has not been revoked. The process also allows the dealer to collect the minimum information (selective disclosure) required to have the vehicle proof of ownership credential issued to you.`,

        obtainCarRegistration: `Having the proof of ownership, you can now ask for your vehicle registration from
        the ministry of transportation. Present your proof of ownership to the Motor
        Vehicle Office website to get the process started. Once completed, you will
        receive your car registration.`,

        obtainCarRegistrationIdLingo: `In other words : Using your vehicle proof of ownership, you can request that a vehicle registration be issued (credential) from the ministry of transportation (trusted issuer). The motor vehicle office (credential verifier) will ask you to share a valid proof of ownership for the vehicle. Once validated, the motor vehicle office will issue (trusted issuer) you your vehicle registration (credential).`,

        getInsurance: `You need car insurance before you can leave with your new car. Good thing
        you can do this online by presenting a valid driver’s license, and vehicle
        registration. Once the process is completed, the insurance company will issue
        you a proof of insurance.`,

        getInsuranceIdLingo: `In other words : You now have all the documents you need to secure vehicle insurance under your name. Once you prove that you have a valid driver's license (verified person, proof of possession) and vehicle registration (proof of possession), insurance will be issued in your name by the insurer of your choice, a private sector organization in your province of residence.`,

        relocate: `You just graduated from university and have accepted a job out of the
        province. It is a super job, in a province that is also known for having the most
        advanced digital government services that are even integrated with the
        financial and insurance services sector. After signing the lease for your new
        apartment, it is now time to update your driver’s license, car registration, health card, and
        insurance.`,

        relocateIdLingo: `In other words : Moving to another province will require you to revoke, update, or replace some credentials.`
    },
    credentials: {
        credentialBoxTitle: 'Checklist to complete the activity',
        birthCertificate: "Birth Certificate",
        utilityBill: "Utility Bill",
        drivingTestResults: "Driving Test Result - on-file",
        healthCard: "Health Card",
        driversLicense: "Driver's License",
        carRegistration: "Vehicle Registration",
        carInsurance: "Vehicle Insurance",
        proofOfOwnership: "Proof of Ownership"
    },
    documentsInHand: {
        documentsInHandBoxTitle: 'Documents in hand',
        birthCertificate: 'Birth Certificate',
        proofOfResidence: 'Proof of Residence',
        driversLicense: 'Driver\'s license',
        carRegistration: 'Vehicle registration',
        carProofOfOwnership: 'Vehicle proof of ownership',
        healthCard: 'Health card',
        driversLicenseProv1: 'Driver\'s license prov 1',
        carRegistrationProv1: 'Car registration prov 1',
        driversLicenseProv2: 'Driver\'s license prov 2',
        carRegistrationProv2: 'Vehicle registration prov 2',
        healthCardProv1: 'Health card prov 1',
        healthCardProv2: 'Health card prov 2',
        apartmentLease: 'ApartmentLease',
        carInsurance: 'Vehicle insurance',
        proofOfOwnerShip: 'Proof of ownership',
        testResults: 'Test results'
    },
    steps: {
        stepsBoxTitle: 'Steps to complete the activity',
        stepVisitMotorVehicleOffice: 'Visit motor <span>vehicle office</span>',
        stepRequestDriverLicense: 'Request driver\'s license',
        stepPresentBirthCertificate: 'Present birth certificate',
        stepPresentProofOfResidency: 'Present proof of residency',
        stepReceiveDriversLicense: 'Receive driver\'s license',
        stepRequestToChallenge: 'Challenge request',
        stepDoTest: 'Do test',
        stepGetYourResults: 'Get your Driver\'s <span>test results</span>',
        stepVisitDigitalGovServiceDesk: 'Visit Digital Government Services Desk',
        stepRequestNewDriverLicense: 'Request new driver\'s <span>license</span>',
        stepShowDriversLicense: 'Show driver\'s license',
        stepShowCarRegistration: 'Show car registration',
        stepShowCarInsurance: 'Show car insurance',
        stepReceiveNewDriversLicense: 'Receive new driver\'s <span>license</span>',
        stepReceiveNewCarRegistration: 'Receive new vehicle registration',
        stepGiveConsentToNotifyInsuranceCompany: 'Give consent to notify insurance company',
        stepShowHealthCard: 'Show health card',
        stepReceiveNewHealthCard: 'Receive new health card',
        stepVisitCarDealer: 'Visit car dealer',
        stepPresentDriversLicense: 'Present driver\'s license',
        stepReceiveCarProofOfOwnership: 'Receive car proof of ownership',
        stepConnecToMotorVehicleOffice: 'Connect to motor vehicle office',
        stepRequestToRegisterTheCar: 'Request vehicle registration',
        stepShowProofOfOwnership: 'Show proof of ownership',
        stepReceiveCarRegistration: 'Receive car registration',
        stepConnecToInsuranceCo: 'Connect to Insurance company',
        stepRequestCarInsurance: 'Request vehicle insurance',
        stepReceiveCarInsurance: 'Receive vehicle insurance',

        descriptions: {
            completeDriverTest: {
                stepVisitMotorVehicleOffice: 'Prospective driver (Holder) visits the Motor Vehicle Office to complete a driving test',
                stepRequestToChallenge: 'The Motor Vehicle Office (Verifier) must verify identity and age. The prospective driver (Holder) is asked for proof of identity and minimum age',
                stepPresentBirthCertificate: 'The prospective driver (Holder) presents their birth certificate from their digital wallet',
                stepDoTest: 'With identity verified, the driver attempts (and passes) the driving test',
                stepGetYourResults: 'The Motor Vehicle Office (now an Issuer) creates a record of driving test result and a credential attesting successful test completion and sends the credential to the prospective driver\'s digital wallet'
            },
            getDriverLicense: {
                stepVisitMotorVehicleOffice: 'With successful driving test result on file, the prospective driver (Holder) is now ready to obtain a driving license',
                stepRequestDriverLicense: 'The prospective driver (Holder) asks for a driving license. The Motor Vehicle Office must verify their elegibility',
                stepPresentBirthCertificate: 'The prospective driver (Holder) is asked for proof of identity and age, and presents their birth certificate from their digital wallet',
                stepPresentProofOfResidency: 'The prospective driver (Holder) is asked for proof of residency, and presents this credential from their digital wallet. Presented credentials are verified (Verifier)',
                stepReceiveDriversLicense: 'The Motor Vehicle Office (now an Issuer) creates a driving license credential and issues it to the prospective driver\'s digital wallet'
            },
            buyACar: {
                stepVisitCarDealer: 'Car buyer (Holder) goes to the car dealer (Verifier) to buy a new vehicle. The Verifier must verify driving license and collect verifiable credential information required to issue a proof of ownership',
                stepPresentDriversLicense: 'Car buyer (Holder) produces their driving license from their digital wallet for the car dealer (Verifier). The credential is verified',
                stepReceiveCarProofOfOwnership: 'The car dealer (now an Issuer) creates a proof of ownership credential and issues it to the car buyer\'s digital wallet'
            },
            obtainCarRegistration: {
                stepConnecToMotorVehicleOffice: 'The vehicle owner (Holder) connects to the Motor Vehicle Office website',
                stepRequestToRegisterTheCar: 'The vehicle owner (Holder) requests a vehicle registration and is asked to submit their proof of ownership by the Motor Vehicle Office (Verifier) website',
                stepShowProofOfOwnership: 'The vehicle owner (Holder) submits a proof of ownership credential from their digital wallet',
                stepReceiveCarRegistration: 'The Motor Vehicle Office (now an Issuer) creates a vehicle registration credential and issues it to the vehicle owner\'s digital wallet'
            },
            getInsurance: {
                stepConnecToInsuranceCo: 'The vehicle owner (Holder) connects to the insurance company (Verifier) website',
                stepRequestCarInsurance: 'The vehicle owner (Holder) requests insurance for their vehicle',
                stepShowDriversLicense: 'The insurance company (Verifier) asks for a driver\'s license and the vehicle owner (Holder) submits it from their digital wallet. The submitted credential is verified',
                stepShowCarRegistration: 'The insurance company (Verifier) asks for a driver\'s vehicle registration and the vehicle owner (Holder) submits it from their digital wallet. The submitted credential is verified',
                stepReceiveCarInsurance: 'The insurance company (now an Issuer) creates a credential attesting to the purchase of insurance and issues it to the vehicle owner\'s digital wallet'
            },
            relocate: {
                stepVisitDigitalGovServiceDesk: 'The client (Holder) visits the Government Services website in their new Province, and asks to complete their "Moving to our Province" process',
                stepRequestNewDriverLicense: 'The client (Holder) indicates they wish to get a new driver license, vehicle registration, and health card',
                stepPresentProofOfResidency: 'The Province (Verifier) asks for a proof of residence and it is submitted from the Holder\'s digital wallet. The submitted credential is verified',
                stepShowDriversLicense: 'The Province (Verifier) asks for the old driving license and it is submitted from the Holder\'s digital wallet. The submitted credential is verified',
                stepShowCarRegistration: 'The Province (Verifier) asks for the previous vehicle registration and it is submitted from the Holder\'s digital wallet. The submitted credential is verified',
                stepShowCarInsurance: 'The Province (Verifier) asks for a proof of insurance and it is submitted from the Holder\'s digital wallet. The submitted credential is verified',
                stepReceiveNewDriversLicense: 'The Province (now an Issuer) creates a new driver license credential and issues it to the client\'s (Holder) digital wallet. Offline, Prov2 will notify Prov1 so they can issue a revocation of their credential',
                stepReceiveNewCarRegistration: 'The Province (now an Issuer) creates a new vehicle registration credential and issues it to the client\'s (Holder) digital wallet. Offline, Prov2 will notify Prov1 so they can issue a revocation of their credential',
                stepGiveConsentToNotifyInsuranceCompany: 'The Province asks for, and receives, permission to notify the insurance company of the change of address. Upon receiving consent, the Province notifies the insurance company in a separate transaction.',
                stepShowHealthCard: 'The Province (once again a Verifier) asks for the old health card and it is submitted from the Holder\'s digital wallet. The submitted credential is verified',
                stepReceiveNewHealthCard: 'The Province (now an Issuer) creates a new health card credential and issues it to the client\'s (Holder) digital wallet. Offline, Prov2 will notify Prov1 so they can issue a revocation of their credential'
            }
        }
    },
    logs: {
        requestForId: 'Request ID',
        requestDigitalId: 'Request digital ID',
        consentToShareId: 'Consent to share ID',
        verifyId: 'Verify ID',
        issueProofOfOwnership: 'Issue proof of ownership',
        storeProofOfOwnership: 'Store proof of ownership',
        requestProofOfResidency: 'Request proof of residency',
        showUtilityBill: 'Show utility bill',
        issueDriversLicense: 'Issue driver\'s license',
        storeDriversLicense: 'Store driver\'s license',
        issueCarInsurance: 'Issue vehicle insurance',
        storeCarInsurance: 'Store vehicle insurance',
        issueCarRegistration: 'Issue vehicle registration',
        storeCarRegistration: 'Store vehicle registration',
        issueTestResults: 'Issue test results',
        storeTestResuls: 'Store test results',
        doingDrivingTest: 'Doing driving test',
        doneDrivingTest: 'Done driving test',
        issueHealthCard: 'Issue health card',
        storeHealthCard: 'Store health card'
    }
};

let strings = enStrings;

function setLanguage(lang) {
    if (lang == 'fr') {
        strings = frStrings;
    }
}

export { strings, setLanguage };
