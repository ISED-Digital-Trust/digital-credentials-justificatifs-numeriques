# IDLab - Education-Portal

## Simple web server deployment

For deployment, simply take the files and directories under [public](public/) and drop them in your choice web server's virtual directory.

## Kubernetes deployment

We created a Continuous Integration (CI) gitlab pipeline to deploy the ISED demo application.

The steps of the pipeline are actually documenting what is required to deploy the application in a kubernetes cluster.

We added comments into the [.gitlab-cy.yml](./.gitlab-ci.yml) file to ease reading and help the reader.
